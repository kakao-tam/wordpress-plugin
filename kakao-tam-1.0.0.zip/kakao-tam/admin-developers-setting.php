<?php
function kakao_tam_validate_is_true($value)
{
    if ($value == "true") return true;
    else false;
}
function kakao_tam_validate_app_key($value)
{
    if (strlen($value) > 31 && strlen($value) < 100) return true;
    else false;
}
function kakao_tam_validate_icon($value)
{
    if ($value == "kakaotalk_sharing_btn_medium.png" || $value == "kakaotalk_sharing_btn_small.png") return true;
    else false;
}
function kakao_tam_validate_icon_display($value)
{
    if ($value == "top" || $value == "bottom") return true;
    else false;
}


if (!current_user_can('manage_options')) {
    wp_die(__('You do not have sufficient permissions to access this page.'));
}

if (is_admin()) {
    if (
        isset($_POST["developers_save"]) && isset($_POST["javascript_key"])
        && kakao_tam_validate_is_true($_POST["developers_save"])
        && kakao_tam_validate_app_key($_POST["javascript_key"])
    ) {
        update_option("javascript_key", esc_html($_POST["javascript_key"]));
    }
    if (
        isset($_POST["kakaotalk_share_save"]) && isset($_POST["kakaotalk_share_icon"])
        && kakao_tam_validate_is_true($_POST["kakaotalk_share_save"])
        && kakao_tam_validate_icon($_POST["kakaotalk_share_icon"])
        && kakao_tam_validate_icon_display($_POST["kakaotalk_share_icon_display"])
    ) {
        update_option("kakaotalk_share_icon", esc_html($_POST["kakaotalk_share_icon"]));
        update_option("kakaotalk_share_icon_display", esc_html($_POST["kakaotalk_share_icon_display"]));
    }
?>
    <form method="post" action="">
        <input type="hidden" name="developers_save" value="true" />
        <h1 class="wp-heading-inline">카카오 디벨로퍼스 설정</h1>
        <div class="wrap">

            <div class="media-toolbar wp-filter">
                <div class="media-toolbar-secondary">
                    <br />
                    <table>
                        <tr>
                            <th scope="row">JavaScript 키</th>
                            <td><input type="text" name="javascript_key" id="post-search-input" size="50" value="<?php echo get_option('javascript_key'); ?>"></td>
                        </tr>
                    </table>

                    <p>
                        ※ <a href="https://developers.kakao.com/" target="_blank">https://developers.kakao.com/</a>에서 "내 애플리케이션 &gt; 앱 설정 &gt; 요약 정보 : JavaScript 키" 를 입력하세요.
                    </p>
                </div>

                <div class="tablenav bottom">
                    <input type="submit" name="Submit" class="button media-button" value="저장" />
                    <br />
                </div>

            </div>
        </div>
    </form>
    <form method="post" action="">
        <input type="hidden" name="kakaotalk_share_save" value="true" />
        <h1 class="wp-heading-inline">카카오톡 공유하기 설정</h1>
        <div class="wrap">

            <div class="media-toolbar wp-filter">
                <div class="media-toolbar-secondary">
                    <table class="form-table">
                        <tr>
                            <th scope="row">아이콘 선택</th>
                            <td class="title column-title has-row-actions column-primary page-title">
                                <div class="color-option <?php echo (get_option('kakaotalk_share_icon') == "kakaotalk_sharing_btn_medium.png") ? "selected" : ""; ?>">
                                    <input type="radio" class="tog" name="kakaotalk_share_icon" value="kakaotalk_sharing_btn_medium.png" <?php echo (get_option('kakaotalk_share_icon') == "kakaotalk_sharing_btn_medium.png") ? "checked" : ""; ?>>
                                    <img src="<?php echo plugins_url('/icon/kakaotalk_sharing_btn_medium.png', __FILE__); ?>" />
                                </div>
                            </td>
                            <td class="title column-title has-row-actions column-primary page-title">
                                <div class="color-option <?php echo (get_option('kakaotalk_share_icon') == "kakaotalk_sharing_btn_small.png") ? "selected" : ""; ?>">
                                    <input type="radio" name="kakaotalk_share_icon" value="kakaotalk_sharing_btn_small.png" <?php echo (get_option('kakaotalk_share_icon') == "kakaotalk_sharing_btn_small.png") ? "checked" : ""; ?>>
                                    <img src="<?php echo plugins_url('/icon/kakaotalk_sharing_btn_small.png', __FILE__); ?>" />
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">위치 선택</th>
                            <td class="title column-title has-row-actions column-primary page-title">
                                <input type="radio" name="kakaotalk_share_icon_display" value="top" <?php echo (get_option('kakaotalk_share_icon_display') == "top") ? "checked" : ""; ?>>
                                Contents 상단
                            </td>
                            <td class="title column-title has-row-actions column-primary page-title">
                                <input type="radio" name="kakaotalk_share_icon_display" value="bottom" <?php echo (get_option('kakaotalk_share_icon_display') == "bottom") ? "checked" : ""; ?>>
                                Contents 하단
                            </td>
                        </tr>
                    </table>
                    <p>
                        ※ 페이지에 직접 적용 하려면 [kakaotalk_share_shortcode] 태그를 추가하세요.
                    </p>
                    <p>
                        ※ 플러그인은 블로그 게시글에 기본 표시되고, 개별 페이지 및 검색 결과에는 표시하지 않습니다.
                    </p>
                </div>

                <div class="tablenav bottom">
                    <input type="submit" name="Submit" class="button media-button" value="저장" />
                    <br />
                </div>

            </div>
        </div>
    </form>
<?php
}
?>