<script>
    function kakao_init() {
        Kakao.init("<?php echo esc_html(get_option('javascript_key')); ?>");
    }
</script>