function shareMessage(url) {
  Kakao.Share.sendScrap({
    requestUrl: url,
  });
}

kakao_init();
