=== kakao-tam ===
Contributors: mcpelee
Donate link: https://googsu.com/
Tags: kakaotalk share
Requires at least: 5.2
Tested up to: 6.0
Stable tag: 1.0.0
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Kakao Talk messenger social sharing function and setting

