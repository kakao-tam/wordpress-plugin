<?php
/*
Plugin Name: kakao-tam
Plugin URI: https://github.com/kakao-tam/wordpress-plugin
Description: Kakao Talk Sharing.
Version: 1.0.0
Requires at least: 5.2
Requires PHP: 7.0
Author: Kakao TAM
Author URI: https://googsu.com
License: GPL2
*/

/*  Copyright 2022  Kakao TAM  (email : tim.l@kakaocorp.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License, version 2, as 
    published by the Free Software Foundation.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

/** Activate */
register_activation_hook(__FILE__, 'kakao_tam_activation_hook');
function kakao_tam_activation_hook()
{
    // option init
    update_option('kakaotalk_share_icon', 'kakaotalk_sharing_btn_small.png');
    update_option('kakaotalk_share_icon_display', 'bottom');
}
/** DeActivate */
register_deactivation_hook(__FILE__, 'kakao_tam_deactivation_hook');
function kakao_tam_deactivation_hook($networkwide)
{
}
/** UnInstall */
register_uninstall_hook(__FILE__, 'kakao_tam_uninstall_hook');
function kakao_tam_uninstall_hook()
{
}

/** add */
add_action('init', 'set_kakao_js_sdk_v1');
add_action('admin_menu', 'kakao_tam_plugin_admin_menu');
add_filter('the_content', 'kakaotalk_share_filter_content');
add_filter('the_excerpt', 'kakaotalk_share_filter_excerpt');
add_filter('plugin_action_links', 'kakaotalk_share_filter_plugin_action_links', 10, 2);
add_shortcode('kakaotalk_share_shortcode', 'kakaotalk_share_shortcode');
/** function */
function set_kakao_js_sdk_v1()
{
    if (!is_admin()) {
        wp_enqueue_script('js_sdk_v1', 'https://t1.kakaocdn.net/kakao_js_sdk/v1/kakao.min.js', null, '1.43.0', true);
        wp_enqueue_script('script_function', plugins_url('script_function.js', __FILE__), null, '1.0.0', true);
        include 'script_init.php';
    }
}

function kakao_tam_plugin_admin_menu()
{
    global $_wp_last_object_menu;
    add_menu_page(__('Developers setting', 'developers_setting'), '카카오디벨로퍼스설정', 'manage_options', 'developers_setting_index', 'developers_setting_index', 'dashicons-admin-generic', $_wp_last_object_menu);
}

function developers_setting_index()
{
    include 'admin-developers-setting.php';
}

function kakaotalk_share_filter_plugin_action_links($links, $file)
{
    static $this_plugin;
    if (!$this_plugin) $this_plugin = plugin_basename(__FILE__);

    if ($file == $this_plugin) {
        $settings_link = '<a href="admin.php?page=developers_setting_index">' . __("Settings") . '</a>';
        array_unshift($links, $settings_link);
    }
    return $links;
}

function kakaotalk_share_filter_content($content)
{
    if (!is_admin()) {
        if (!is_page() && !is_search() && !is_home()) {
            if (get_option('kakaotalk_share_icon_display') == "top") return kakaotalk_share() . $content;
            else return $content . kakaotalk_share();
        }
    }
    return $content;
}
function kakaotalk_share_filter_excerpt($content)
{
    return $content;
}

function kakaotalk_share_shortcode()
{
    echo kakaotalk_share();
}
function kakaotalk_share()
{
    $url = get_permalink();
    return '
    <a name="kakaotalk-sharing-btn" href="javascript:shareMessage(\'' . $url . '\')">
    <img src="' . plugins_url('/icon/' . get_option('kakaotalk_share_icon'), __FILE__) . '"
      alt="카카오톡 공유 버튼" />
    </a>    
    ';
}
